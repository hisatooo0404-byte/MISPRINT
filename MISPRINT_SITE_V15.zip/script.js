(() => {
  const body = document.body;
  const root = document.documentElement;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = window.matchMedia('(pointer:fine)').matches;

  // Loader: keeps the entrance short and predictable.
  const loader = document.querySelector('.loader');
  const loadNum = document.querySelector('#loadNum');
  const loadBar = loader?.querySelector('.loader__bar i');
  if (loader) {
    let progress = 0;
    const started = performance.now();
    const duration = reduceMotion ? 180 : 900;
    const tick = (now) => {
      progress = Math.min(100, Math.round(((now - started) / duration) * 100));
      if (loadNum) loadNum.textContent = String(progress).padStart(2, '0');
      if (loadBar) loadBar.style.transform = `scaleX(${progress / 100})`;
      if (progress < 100) requestAnimationFrame(tick);
      else setTimeout(() => loader.classList.add('is-done'), reduceMotion ? 40 : 180);
    };
    requestAnimationFrame(tick);
  }

  // Scroll feedback + sticky header state.
  const progressBar = document.querySelector('.scroll-progress span');
  const header = document.querySelector('[data-header]');
  const updateScrollUI = () => {
    const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    const progress = Math.min(1, window.scrollY / max);
    if (progressBar) progressBar.style.transform = `scaleX(${progress})`;
    if (header) header.classList.toggle('is-scrolled', window.scrollY > 20);
  };
  addEventListener('scroll', updateScrollUI, { passive: true });
  updateScrollUI();

  // Reveal motion uses transform only: text never depends on opacity to exist.
  const revealEls = [...document.querySelectorAll('.reveal')];
  if (!reduceMotion && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -9% 0px', threshold: 0.03 });
    revealEls.forEach(el => observer.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('is-visible'));
  }

  // Scroll-linked hero depth and manifesto motion.
  const heroCenter = document.querySelector('[data-hero-center]');
  const manifesto = document.querySelector('.manifesto');
  const parallaxEls = [...document.querySelectorAll('[data-parallax]')];
  let raf = 0;
  const updateMotion = () => {
    raf = 0;
    if (reduceMotion) return;
    const y = window.scrollY;
    if (heroCenter) {
      const range = Math.min(1, y / Math.max(window.innerHeight * .85, 1));
      heroCenter.style.transform = `translate3d(0,${(-range * 30).toFixed(2)}px,0) scale(${(1 - range * .025).toFixed(4)})`;
    }
    if (manifesto) {
      const r = manifesto.getBoundingClientRect();
      const raw = (window.innerHeight - r.top) / Math.max(window.innerHeight + r.height, 1);
      const progress = Math.max(0, Math.min(1, raw));
      manifesto.style.setProperty('--progress', progress.toFixed(4));
    }
    parallaxEls.forEach((el) => {
      const r = el.getBoundingClientRect();
      const amount = Number(el.dataset.parallax || 16);
      const center = r.top + r.height / 2;
      const p = Math.max(-1, Math.min(1, (center - window.innerHeight / 2) / Math.max(window.innerHeight, 1)));
      el.style.setProperty('--scroll-shift', `${(-p * amount).toFixed(2)}px`);
    });
  };
  const requestMotion = () => { if (!raf) raf = requestAnimationFrame(updateMotion); };
  addEventListener('scroll', requestMotion, { passive: true });
  addEventListener('resize', requestMotion);
  updateMotion();

  // Custom pointer and restrained micro-interactions.
  const cursor = document.querySelector('.cursor');
  const cursorLabel = cursor?.querySelector('.cursor__label');
  if (cursor && finePointer && !reduceMotion) {
    let tx = innerWidth / 2, ty = innerHeight / 2, cx = tx, cy = ty;
    const draw = () => {
      cx += (tx - cx) * .2;
      cy += (ty - cy) * .2;
      cursor.style.transform = `translate3d(${cx - cursor.offsetWidth / 2}px,${cy - cursor.offsetHeight / 2}px,0)`;
      requestAnimationFrame(draw);
    };
    draw();
    addEventListener('pointermove', (e) => { tx = e.clientX; ty = e.clientY; cursor.classList.add('is-ready'); }, { passive: true });
    addEventListener('pointerleave', () => cursor.classList.remove('is-ready','is-active'), { passive: true });

    document.querySelectorAll('[data-cursor]').forEach((el) => {
      el.addEventListener('pointerenter', () => { cursor.classList.add('is-active'); if (cursorLabel) cursorLabel.textContent = el.dataset.cursor || ''; });
      el.addEventListener('pointerleave', () => { cursor.classList.remove('is-active'); if (cursorLabel) cursorLabel.textContent = ''; });
    });

    document.querySelectorAll('.magnetic').forEach((el) => {
      el.addEventListener('pointermove', (e) => {
        const r = el.getBoundingClientRect();
        const dx = e.clientX - (r.left + r.width / 2);
        const dy = e.clientY - (r.top + r.height / 2);
        el.style.transform = `translate3d(${(dx * .055).toFixed(2)}px,${(dy * .055).toFixed(2)}px,0)`;
      });
      el.addEventListener('pointerleave', () => { el.style.transform = ''; });
    });

    document.querySelectorAll('.world-card,.member-card--featured').forEach((card) => {
      card.addEventListener('pointermove', (e) => {
        const r = card.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width - .5;
        const py = (e.clientY - r.top) / r.height - .5;
        const amount = card.classList.contains('member-card--featured') ? 1.1 : 1.8;
        card.style.transform = `perspective(1200px) rotateX(${(-py * amount).toFixed(2)}deg) rotateY(${(px * amount).toFixed(2)}deg)`;
      });
      card.addEventListener('pointerleave', () => { card.style.transform = ''; });
    });
  }

  // Mobile navigation.
  const menu = document.querySelector('.menu');
  const nav = document.querySelector('.nav');
  menu?.addEventListener('click', () => {
    const open = nav?.classList.toggle('is-open') || false;
    body.classList.toggle('menu-open', open);
    menu.classList.toggle('is-open', open);
    menu.setAttribute('aria-expanded', String(open));
  });
  nav?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    nav.classList.remove('is-open'); body.classList.remove('menu-open'); menu?.classList.remove('is-open'); menu?.setAttribute('aria-expanded','false');
  }));

  // Highlight current section.
  const navLinks = [...document.querySelectorAll('.nav a')];
  const sections = ['about','worlds','members','join'].map(id => document.getElementById(id)).filter(Boolean);
  if ('IntersectionObserver' in window) {
    const navObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        navLinks.forEach(link => link.classList.toggle('is-current', link.getAttribute('href') === `#${entry.target.id}`));
      });
    }, { rootMargin: '-42% 0px -48% 0px', threshold: 0 });
    sections.forEach(s => navObserver.observe(s));
  }

  // Member profile modal.
  const modal = document.getElementById('memberModal');
  let previousFocus = null;
  const openModal = () => {
    if (!modal) return;
    previousFocus = document.activeElement;
    modal.classList.add('is-open'); modal.setAttribute('aria-hidden','false'); body.classList.add('modal-open');
    modal.querySelector('.modal__close')?.focus({ preventScroll: true });
  };
  const closeModal = () => {
    if (!modal) return;
    modal.classList.remove('is-open'); modal.setAttribute('aria-hidden','true'); body.classList.remove('modal-open');
    previousFocus?.focus?.({ preventScroll: true });
  };
  document.querySelectorAll('[data-open-member]').forEach(node => node.addEventListener('click', (e) => { e.stopPropagation(); openModal(); }));
  document.querySelectorAll('[data-close-modal]').forEach(node => node.addEventListener('click', closeModal));
  document.querySelector('.member-card--featured')?.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.key === ' ') && !e.target.closest('button,a')) { e.preventDefault(); openModal(); }
  });
  addEventListener('keydown', e => { if (e.key === 'Escape' && modal?.classList.contains('is-open')) closeModal(); });

  // Multi-step application.
  const form = document.querySelector('#applyForm');
  const status = document.querySelector('#applyStatus');
  const pages = [...document.querySelectorAll('.form-page')];
  const stepButtons = [...document.querySelectorAll('.form-step')];
  let currentStep = 1;
  const setStep = (step, scroll = true) => {
    currentStep = Math.min(3, Math.max(1, step));
    pages.forEach(p => p.classList.toggle('is-active', Number(p.dataset.page) === currentStep));
    stepButtons.forEach(b => b.classList.toggle('is-active', Number(b.dataset.step) === currentStep));
    if (scroll && form) form.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
  };
  const validatePage = (pageNumber) => {
    const page = form?.querySelector(`.form-page[data-page="${pageNumber}"]`);
    if (!page) return true;
    for (const field of page.querySelectorAll('input,select,textarea')) {
      if (field.name === 'website') continue;
      if (!field.checkValidity()) { field.reportValidity(); field.focus({ preventScroll: true }); return false; }
    }
    return true;
  };
  document.querySelectorAll('[data-next]').forEach(btn => btn.addEventListener('click', () => { if (validatePage(currentStep)) setStep(Number(btn.dataset.next)); }));
  document.querySelectorAll('[data-back]').forEach(btn => btn.addEventListener('click', () => setStep(Number(btn.dataset.back))));
  stepButtons.forEach(btn => btn.addEventListener('click', () => { const target = Number(btn.dataset.step); if (target <= currentStep || validatePage(currentStep)) setStep(target); }));

  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    if ([1,2,3].some(page => !validatePage(page))) return;
    const data = Object.fromEntries(new FormData(form).entries());
    if (data.website) return;
    const button = form.querySelector('.apply__submit');
    if (button) button.disabled = true;
    if (status) { status.className = 'apply__status'; status.textContent = 'SENDING TO DISCORD / PLEASE WAIT…'; }
    try {
      const response = await fetch('/api/apply', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data) });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || '送信に失敗しました。');
      if (status) { status.classList.add('is-success'); status.textContent = 'APPLICATION RECEIVED — Discordへ送信しました。'; }
      form.reset(); setStep(1, false);
    } catch (error) {
      if (status) { status.classList.add('is-error'); status.textContent = `SEND ERROR — ${error.message}`; }
    } finally {
      if (button) button.disabled = false;
    }
  });
})();
