MISPRINT SITE V14

Independent gaming & creative collective website.

Design focus:
- monochrome / cyan accent / editorial typography
- responsive grid for desktop and mobile
- continuous marquee using duplicated equal-width groups
- scroll-linked motion + lightweight micro-interactions
- member profile modal
- multi-step application form
- Discord webhook via Cloudflare Pages Function

Files:
- index.html
- style.css
- script.js
- assets/brand-mark.png
- assets/favicon.svg
- assets/misprint-hisato.jpg
- functions/api/apply.js

Discord setup:
1. Create a Discord webhook in the destination channel.
2. In Cloudflare Pages, add a Secret named DISCORD_WEBHOOK_URL.
3. Deploy the project with its functions/ directory.


V15: mobile JOIN/application overflow hardening; form width, step tabs, inputs, headings and buttons are constrained to viewport width.
