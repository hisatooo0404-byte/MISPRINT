const ALLOWED_FIELDS = [
  "name", "discord", "age", "source", "social",
  "role", "game", "platform", "input", "experience", "hours",
  "strength", "goal", "motivation"
];

const LIMITS = {
  name: 60, discord: 80, age: 20, source: 40, social: 240,
  role: 80, game: 80, platform: 40, input: 80, experience: 1200,
  hours: 140, strength: 1000, goal: 1000, motivation: 1400
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
  });
}

function clean(value, max = 500) {
  return String(value ?? "").trim().slice(0, max);
}

export async function onRequestPost(context) {
  try {
    const webhook = context.env.DISCORD_WEBHOOK_URL;
    if (!webhook) return json({ error: "Discord webhook is not configured." }, 500);

    const contentType = context.request.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      return json({ error: "JSON request required." }, 415);
    }

    const data = await context.request.json();
    if (data?.website) return json({ ok: true });

    const cleaned = {};
    for (const field of ALLOWED_FIELDS) cleaned[field] = clean(data?.[field], LIMITS[field] ?? 500);

    const required = ["name", "discord", "role", "game", "hours", "strength", "goal", "motivation"];
    const missing = required.filter((key) => !cleaned[key]);
    if (missing.length) return json({ error: "必須項目を入力してください。" }, 400);

    if (cleaned.social && !/^https?:\/\//i.test(cleaned.social)) {
      return json({ error: "SNS / Portfolio URL は https:// から入力してください。" }, 400);
    }

    const fields = [
      ["DISPLAY NAME", cleaned.name, true],
      ["DISCORD", cleaned.discord, true],
      ["AGE RANGE", cleaned.age || "未回答", true],
      ["FOUND VIA", cleaned.source || "未回答", true],
      ["SOCIAL / PORTFOLIO", cleaned.social || "なし", false],
      ["ROLE", cleaned.role, true],
      ["MAIN GAME / GENRE", cleaned.game, true],
      ["PLATFORM", cleaned.platform || "未回答", true],
      ["INPUT / SETUP", cleaned.input || "未回答", true],
      ["AVAILABILITY", cleaned.hours, false],
      ["EXPERIENCE / ACHIEVEMENTS", cleaned.experience || "なし", false],
      ["STRENGTH", cleaned.strength, false],
      ["WHAT THEY WANT TO BUILD", cleaned.goal, false],
      ["WHY MISPRINT", cleaned.motivation, false]
    ];

    const embed = {
      title: "NEW MISPRINT APPLICATION",
      description: "Websiteから新しい応募が届きました。",
      color: 7653119,
      fields: fields.map(([name, value, inline]) => ({ name, value, inline })),
      footer: { text: "MISPRINT / APPLICATION" },
      timestamp: new Date().toISOString()
    };

    const response = await fetch(webhook, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        username: "MISPRINT APPLICATION",
        embeds: [embed],
        allowed_mentions: { parse: [] }
      })
    });

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.error("Discord webhook error", response.status, detail.slice(0, 500));
      return json({ error: "Discordへの送信に失敗しました。" }, 502);
    }

    return json({ ok: true });
  } catch (error) {
    console.error("Application handler error", error);
    return json({ error: "応募処理中にエラーが発生しました。" }, 500);
  }
}
